import SwiftUI
import SceneKit

struct GuitarSceneView: UIViewRepresentable {
    let note: GuitarNote?

    func makeCoordinator() -> Coordinator {
        Coordinator()
    }

    func makeUIView(context: Context) -> SCNView {
        let view = SCNView()
        view.backgroundColor = .clear
        view.antialiasingMode = .multisampling4X
        view.autoenablesDefaultLighting = true
        view.allowsCameraControl = true

        let scene = SCNScene()
        view.scene = scene

        if let url = Bundle.main.url(forResource: "guitar", withExtension: "obj"),
           let guitar = try? SCNScene(url: url, options: nil) {
            let holder = SCNNode()
            guitar.rootNode.childNodes.forEach { holder.addChildNode($0) }
            holder.scale = SCNVector3(0.0022, 0.0022, 0.0022)
            holder.eulerAngles = SCNVector3(-.pi / 2, 0, 0)
            holder.position = SCNVector3(0, -0.75, 0)
            scene.rootNode.addChildNode(holder)
        }

        context.coordinator.installOverlay(in: scene)

        let cameraNode = SCNNode()
        cameraNode.camera = SCNCamera()
        cameraNode.camera?.fieldOfView = 48
        cameraNode.position = SCNVector3(0, 0.15, 4.6)
        scene.rootNode.addChildNode(cameraNode)

        return view
    }

    func updateUIView(_ uiView: SCNView, context: Context) {
        context.coordinator.flash(note)
    }

    final class Coordinator {
        var strings: [SCNNode] = []
        var marker: SCNNode?

        func installOverlay(in scene: SCNScene) {
            // Player view: high e at top, low E at bottom.
            for index in 0..<6 {
                let geometry = SCNCylinder(
                    radius: 0.006 + Double(index) * 0.0012,
                    height: 2.85
                )
                geometry.radialSegmentCount = 8
                geometry.firstMaterial?.diffuse.contents = UIColor.white.withAlphaComponent(0.38)
                geometry.firstMaterial?.emission.contents = UIColor.clear

                let node = SCNNode(geometry: geometry)
                node.eulerAngles.z = -.pi / 2
                node.position = SCNVector3(0, 0.30 - Float(index) * 0.12, 0.34)
                node.name = "String_\(index + 1)"
                scene.rootNode.addChildNode(node)
                strings.append(node)
            }

            // Subtle fret guides.
            for fret in 0...24 {
                let x = fretX(fret)
                let geometry = SCNBox(
                    width: 0.008,
                    height: 0.68,
                    length: 0.012,
                    chamferRadius: 0.002
                )
                geometry.firstMaterial?.diffuse.contents = UIColor.white.withAlphaComponent(0.12)

                let node = SCNNode(geometry: geometry)
                node.position = SCNVector3(x, 0, 0.33)
                scene.rootNode.addChildNode(node)
            }
        }

        func flash(_ note: GuitarNote?) {
            marker?.removeFromParentNode()
            marker = nil

            guard let note,
                  (1...6).contains(note.string),
                  let parent = strings.first?.parent else {
                return
            }

            let index = note.string - 1
            let stringNode = strings[index]
            let hue = CGFloat(note.midi % 12) / 12.0
            let neon = UIColor(hue: hue, saturation: 0.88, brightness: 1, alpha: 1)

            stringNode.geometry?.firstMaterial?.emission.contents = neon.withAlphaComponent(0.7)
            stringNode.opacity = 0.82

            SCNTransaction.begin()
            SCNTransaction.animationDuration = 0.22
            stringNode.opacity = 0.4
            SCNTransaction.completionBlock = {
                stringNode.geometry?.firstMaterial?.emission.contents = UIColor.clear
            }
            SCNTransaction.commit()

            let sphere = SCNSphere(radius: 0.055)
            sphere.segmentCount = 24
            sphere.firstMaterial?.diffuse.contents = neon
            sphere.firstMaterial?.emission.contents = neon
            sphere.firstMaterial?.lightingModel = .constant

            let markerNode = SCNNode(geometry: sphere)
            markerNode.position = SCNVector3(
                fretX(note.fret),
                0.30 - Float(index) * 0.12,
                0.38
            )
            parent.addChildNode(markerNode)
            marker = markerNode

            markerNode.scale = SCNVector3(0.5, 0.5, 0.5)
            let pulse = SCNAction.sequence([
                .scale(to: 1.25, duration: 0.05),
                .scale(to: 1.0, duration: 0.12),
                .fadeOut(duration: 0.16)
            ])
            markerNode.runAction(pulse)

            let basePosition = stringNode.position
            let vibration = SCNAction.sequence([
                .moveBy(x: 0, y: 0.018, z: 0, duration: 0.025),
                .moveBy(x: 0, y: -0.036, z: 0, duration: 0.04),
                .move(to: basePosition, duration: 0.07)
            ])
            stringNode.runAction(vibration)
        }

        private func fretX(_ fret: Int) -> Float {
            let clamped = max(0, min(24, fret))
            let t = Float(clamped) / 24.0
            return -1.38 + 2.76 * (1 - pow(1 - t, 1.28))
        }
    }
}
