import SwiftUI
import UniformTypeIdentifiers

struct ContentView: View {
    @EnvironmentObject var model: AppModel
    @State private var importer = false
    @State private var demoRunning = false

    var body: some View {
        ZStack {
            LinearGradient(
                colors: [Color.black, Color(red: 0.05, green: 0.06, blue: 0.09)],
                startPoint: .top,
                endPoint: .bottom
            )
            .ignoresSafeArea()

            VStack(spacing: 14) {
                HStack {
                    VStack(alignment: .leading, spacing: 2) {
                        Text("NEON FRET")
                            .font(.system(size: 24, weight: .black, design: .rounded))
                        Text(model.songName)
                            .font(.caption)
                            .foregroundStyle(.secondary)
                            .lineLimit(1)
                    }
                    Spacer()
                    Button {
                        importer = true
                    } label: {
                        Image(systemName: "music.note.list")
                            .font(.title2)
                            .padding(10)
                            .background(.thinMaterial, in: Circle())
                    }
                }
                .padding(.horizontal)

                NoteHeader(
                    current: model.currentNote?.name ?? "–",
                    next: model.nextNote?.name ?? "–"
                )

                GuitarSceneView(note: model.currentNote)
                    .clipShape(RoundedRectangle(cornerRadius: 22))
                    .padding(.horizontal)

                controls
            }
            .padding(.vertical)
        }
        .preferredColorScheme(.dark)
        .fileImporter(
            isPresented: $importer,
            allowedContentTypes: [.audio],
            allowsMultipleSelection: false
        ) { result in
            if case .success(let urls) = result, let url = urls.first {
                model.importSong(from: url)
            }
        }
    }

    private var controls: some View {
        VStack(spacing: 12) {
            HStack(spacing: 24) {
                Button {
                    model.loopEnabled.toggle()
                } label: {
                    Image(systemName: model.loopEnabled ? "repeat.circle.fill" : "repeat.circle")
                }

                Button {
                    model.togglePlayback()
                } label: {
                    Image(systemName: model.isPlaying ? "pause.circle.fill" : "play.circle.fill")
                        .font(.system(size: 48))
                }

                Button {
                    runDemo()
                } label: {
                    Image(systemName: "sparkles")
                    Text("Demo")
                }
                .buttonStyle(.bordered)
            }
            .font(.title2)

            HStack {
                Text("Tempo")
                Slider(
                    value: Binding(
                        get: { Double(model.playbackRate) },
                        set: { model.playbackRate = Float($0) }
                    ),
                    in: 0.5...1.0
                )
                Text("\(Int(model.playbackRate * 100)) %")
                    .monospacedDigit()
            }
            .font(.caption)
            .padding(.horizontal)
        }
        .padding(.horizontal)
    }

    private func runDemo() {
        guard !demoRunning else { return }
        demoRunning = true
        model.currentIndex = 0

        Task { @MainActor in
            for index in model.notes.indices {
                model.currentIndex = index
                try? await Task.sleep(for: .milliseconds(480))
            }
            demoRunning = false
        }
    }
}

private struct NoteHeader: View {
    let current: String
    let next: String

    var body: some View {
        HStack(alignment: .firstTextBaseline, spacing: 16) {
            Text(current)
                .font(.system(size: 46, weight: .black, design: .rounded))
                .shadow(color: .cyan, radius: 12)
            Text(next)
                .font(.system(size: 28, weight: .bold, design: .rounded))
                .foregroundStyle(.white.opacity(0.28))
        }
        .frame(maxWidth: .infinity)
        .animation(.easeOut(duration: 0.12), value: current)
    }
}
