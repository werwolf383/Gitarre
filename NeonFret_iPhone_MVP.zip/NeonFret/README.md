# Neon Fret – iPhone MVP

Native iOS SwiftUI + SceneKit prototype.

## Implemented
- Local audio import through iOS Files picker (audio is copied into the app's Documents/Musik directory).
- Local AVAudioPlayer playback foundation, 50–100% speed control and loop state UI.
- Imported 3D guitar body derived from the supplied `e-gitarre.glb`.
- Player-view string order: high e, B, G, D, A, low E.
- 24-fret mapping overlay.
- Current note + translucent next note above the guitar.
- Neon fret marker, whole-string glow and short string vibration animation.
- Test-note demo sequence so the complete visual pipeline can be validated before AI transcription.
- FretMapper for standard tuning (E2 A2 D3 G3 B3 E4) and playable position candidates.

## Next engineering milestone
Replace the demo note sequence with timestamped note events from local pitch detection / lead-guitar separation. Keep the analysis interface separate from rendering so ML can be swapped without changing the UI.

## Build
Open `NeonFret.xcodeproj` in Xcode on macOS, choose an iPhone target, set your signing team, then Run.

The supplied GLB remains the source asset. `guitar.obj` is an iOS-friendly static MVP conversion. For production, create a USDZ version preserving materials and explicitly named string nodes/markers.
