import Foundation
import AVFoundation

@MainActor final class AppModel: ObservableObject {
    @Published var importedURL: URL?
    @Published var songName = "Kein Song geladen"
    @Published var isPlaying = false
    @Published var currentIndex = 0
    @Published var playbackRate: Float = 1
    @Published var loopEnabled = false

    // Test phrase validates the entire visual pipeline before AI analysis is added.
    @Published var notes: [GuitarNote] = [
        .init(name:"E4", midi:64, string:2, fret:5, duration:0.45),
        .init(name:"F♯4", midi:66, string:2, fret:7, duration:0.45),
        .init(name:"G4", midi:67, string:2, fret:8, duration:0.45),
        .init(name:"A4", midi:69, string:1, fret:5, duration:0.45),
        .init(name:"B4", midi:71, string:1, fret:7, duration:0.55)
    ]
    private var player: AVAudioPlayer?

    var currentNote: GuitarNote? { notes.indices.contains(currentIndex) ? notes[currentIndex] : nil }
    var nextNote: GuitarNote? { notes.indices.contains(currentIndex + 1) ? notes[currentIndex + 1] : nil }

    func importSong(from url: URL) {
        let accessed = url.startAccessingSecurityScopedResource()
        defer { if accessed { url.stopAccessingSecurityScopedResource() } }
        do {
            let fm = FileManager.default
            let docs = fm.urls(for: .documentDirectory, in: .userDomainMask)[0]
            let music = docs.appendingPathComponent("Musik", isDirectory: true)
            try fm.createDirectory(at: music, withIntermediateDirectories: true)
            let dest = music.appendingPathComponent(url.lastPathComponent)
            if fm.fileExists(atPath: dest.path) { try fm.removeItem(at: dest) }
            try fm.copyItem(at: url, to: dest)
            importedURL = dest; songName = dest.deletingPathExtension().lastPathComponent
            player = try AVAudioPlayer(contentsOf: dest); player?.enableRate = true
        } catch { songName = "Import fehlgeschlagen" }
    }

    func togglePlayback() {
        guard let player else { return }
        if player.isPlaying { player.pause(); isPlaying = false }
        else { player.rate = playbackRate; player.play(); isPlaying = true }
    }
}
