import Foundation

struct GuitarNote: Identifiable, Equatable {
    let id = UUID()
    let name: String
    let midi: Int
    let string: Int // 1=high e ... 6=low E
    let fret: Int
    let duration: TimeInterval
}

enum FretMapper {
    // Player view: high e at top, low E at bottom.
    static let openMIDI = [64, 59, 55, 50, 45, 40]
    static func positions(for midi: Int, maxFret: Int = 24) -> [(string: Int, fret: Int)] {
        openMIDI.enumerated().compactMap { idx, open in
            let fret = midi - open
            return (0...maxFret).contains(fret) ? (idx + 1, fret) : nil
        }
    }
    static func preferredPosition(for midi: Int, previous: (Int, Int)? = nil) -> (Int, Int)? {
        let p = positions(for: midi)
        guard !p.isEmpty else { return nil }
        guard let previous else { return p.min(by: { $0.fret < $1.fret }).map { ($0.string,$0.fret) } }
        return p.min { a,b in abs(a.fret-previous.1)+abs(a.string-previous.0)*2 < abs(b.fret-previous.1)+abs(b.string-previous.0)*2 }.map { ($0.string,$0.fret) }
    }
}
