import SwiftUI
import SceneKit

struct GuitarSceneView: UIViewRepresentable {
    let note: GuitarNote?
    func makeCoordinator() -> Coordinator { Coordinator() }
    func makeUIView(context: Context) -> SCNView {
        let v=SCNView(); v.backgroundColor=.clear; v.antialiasingMode=.multisampling4X; v.autoenablesDefaultLighting=true; v.allowsCameraControl=true
        let scene=SCNScene(); v.scene=scene
        if let url=Bundle.main.url(forResource:"guitar",withExtension:"obj"), let guitar=try? SCNScene(url:url,options:nil) {
            let holder=SCNNode(); guitar.rootNode.childNodes.forEach{ holder.addChildNode($0) }
            holder.scale=SCNVector3(0.0022,0.0022,0.0022); holder.eulerAngles=SCNVector3(-.pi/2,0,0); holder.position=SCNVector3(0,-0.75,0)
            scene.rootNode.addChildNode(holder)
        }
        context.coordinator.installOverlay(in:scene)
        let cam=SCNNode(); cam.camera=SCNCamera(); cam.camera?.fieldOfView=48; cam.position=SCNVector3(0,0.15,4.6); scene.rootNode.addChildNode(cam)
        return v
    }
    func updateUIView(_ uiView: SCNView, context: Context) { context.coordinator.flash(note) }

    final class Coordinator {
        var strings:[SCNNode]=[]; var marker:SCNNode?
        func installOverlay(in scene:SCNScene) {
            // Player view: high e at top, low E at bottom.
            for i in 0..<6 {
                let g=SCNCylinder(radius:0.006 + Double(i)*0.0012,height:2.85); g.radialSegmentCount=8
                g.firstMaterial?.diffuse.contents=UIColor.white.withAlphaComponent(0.38); g.firstMaterial?.emission.contents=UIColor.clear
                let n=SCNNode(geometry:g); n.eulerAngles.z = -.pi/2; n.position=SCNVector3(0,0.30-Float(i)*0.12,0.34); n.name="String_\(i+1)"; scene.rootNode.addChildNode(n); strings.append(n)
            }
            // subtle fret guides
            for fret in 0...24 {
                let x = fretX(fret)
                let b=SCNBox(width:0.008,height:0.68,length:0.012,chamferRadius:0.002); b.firstMaterial?.diffuse.contents=UIColor.white.withAlphaComponent(0.12)
                let n=SCNNode(geometry:b); n.position=SCNVector3(x,0.0,0.33); scene.rootNode.addChildNode(n)
            }
        }
        func flash(_ note:GuitarNote?) {
            marker?.removeFromParentNode(); marker=nil
            guard let note, (1...6).contains(note.string), let parent=strings.first?.parent else { return }
            let idx=note.string-1, string=strings[idx]
            let hue=CGFloat((note.midi % 12))/12.0; let neon=UIColor(hue:hue,saturation:0.88,brightness:1,alpha:1)
            string.geometry?.firstMaterial?.emission.contents=neon.withAlphaComponent(0.7)
            string.opacity=0.82
            SCNTransaction.begin(); SCNTransaction.animationDuration=0.22; string.opacity=0.4; SCNTransaction.completionBlock={ string.geometry?.firstMaterial?.emission.contents=UIColor.clear }; SCNTransaction.commit()
            let s=SCNSphere(radius:0.055); s.segmentCount=24; s.firstMaterial?.diffuse.contents=neon; s.firstMaterial?.emission.contents=neon; s.firstMaterial?.lightingModel = .constant
            let m=SCNNode(geometry:s); m.position=SCNVector3(fretX(note.fret),0.30-Float(idx)*0.12,0.38); parent.addChildNode(m); marker=m
            m.scale=SCNVector3(0.5,0.5,0.5); let pulse=SCNAction.sequence([.scale(to:1.25,duration:0.05),.scale(to:1,duration:0.12),.fadeOut(duration:0.16)]); m.runAction(pulse)
            let base=string.position; string.runAction(.sequence([.moveBy(x:0,y:0.018,z:0,duration:0.025),.moveBy(x:0,y:-0.036,z:0,duration:0.04),.move(to:base,duration:0.07)]))
        }
        private func fretX(_ fret:Int)->Float {
            let clamped=max(0,min(24,fret)); let t=Float(clamped)/24.0
            return -1.38 + 2.76 * (1 - pow(1-t,1.28))
        }
    }
}
